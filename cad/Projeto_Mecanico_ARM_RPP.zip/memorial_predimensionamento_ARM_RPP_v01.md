# A.R.M. — Memorial de pré-dimensionamento para CAD
**Versão:** 0.1 | **Data:** 12/11/2026 | **Status:** CONCEITUAL — NÃO VALIDADO PARA VOO OU FABRICAÇÃO

## 1. Base documental e escopo

O projeto apresentado no relatório da disciplina Dinâmica de Sistemas Robóticos usa um drone para recuperação e entrega de ferramentas em ambiente industrial/offshore e um manipulador RPP com junta revoluta, duas prismáticas e eletroímã de captura. Os slides da cinemática direta definem a posição da ponta por x=-d3·sen(theta1), y=d3·cos(theta1), z=l1+d2, em um referencial local. O desenho original não fornece medidas de fabricação, escolha do drone nem massa e formato das ferramentas. Todos os valores não presentes nesses materiais são **hipóteses de pré-dimensionamento**.

A presente especificação fecha um conjunto coerente de dimensões **para gerar um CAD conceitual paramétrico**. Ela não afirma ter resolvido a viabilidade de voo, o atendimento à missão em frente a painéis verticais ou um detalhamento fabril homologado.

## 2. Requisitos assumidos para o CAD inicial

- Aeronave de referência: **DJI Matrice 400** (9,74 kg equipada, 15,8 kg MTOW, até 6 kg de carga útil no terceiro suporte com fixação por parafusos), apenas como envelope de análise, não como aeronave definida pelo grupo.
- Ferramentas: **0,30 kg** no máximo para o conceito inicial; interfaces padronizadas de aço plano de **Ø30 x 3 mm**.
- Curso vertical `d2`: **100 mm**; curso horizontal: **200 mm**.
- TCP radial `d3`: **100–300 mm**; `d3` é a distância horizontal total do TCP ao eixo, não apenas o curso do atuador.
- Curso rotacional: **-90° a +90°**.
- Distância fixa do TCP no home, `l1`: **120 mm**, em referencial local com eixo Z definido coerentemente com a orientação de instalação. A transformação entre referencial local e o do drone deve ser explícita.
- Cenário inicialmente modelado: estação de coleta que permita acesso por baixo/próximo do drone. **Não comprova** acesso a painéis verticais convencionais.

## 3. Dimensões propostas para o CAD

Todas em milímetros, exceto quando indicado.

| Conjunto | Peças / dimensões adotadas | Natureza |
|---|---|---|
| Interface ao drone | Placa Al 6061-T6 de 160 x 120 x 4, furos OEM pendentes | Hipótese |
| Mesa rotativa | Disco de alumínio Ø90 x 6; eixo Ø12 x 95; alojamento Ø44 x 75 | Hipótese |
| Mancal de rotação | 2 rolamentos SKF 6001, 12 x 28 x 8, separados 45 mm entre centros | Rolamento catalogado, geometria de montagem hipótese |
| Atuador de rotação | ROBOTIS XM430-W350-T, 28,5 x 46,5 x 34, 82 g | Fabricante |
| Estrutura vertical | Placa 100 x 240 x 3, Al 6061-T6 | Hipótese |
| Guias verticais | 2 trilhos igus N27 de 220 mm; centros separados 60 mm; 4 patins | Catálogo + corte/arranjo hipotéticos |
| Carro vertical | Placa 100 x 90 x 4 de Al 6061-T6 | Hipótese |
| Avanço vertical | Actuonix T16-100-64-12-P; 100 mm curso; 138 g; 12 V | Fabricante |
| Estrutura horizontal | Placa 60 x 320 x 3 de Al 6061-T6 | Hipótese |
| Guia horizontal | 1 trilho igus N40 de 320 mm e 2 patins espaçados 50 mm | Catálogo + corte/arranjo hipotéticos |
| Viga móvel | Tubo quadrado Al 6061-T6 20 x 20 x 2, comprimento 320 mm | Hipótese |
| Avanço horizontal | Actuonix T16-200-64-12-P; 200 mm curso; 160 g; 12 V | Fabricante |
| Suporte do magneto | Placa 50 x 40 x 4 de alumínio | Hipótese |
| Eletroímã | Adafruit P25/20: Ø25 x 20, 55,3 g, 5 V, 0,3 A | Fabricante |
| Ferramenta de referência | Até 160 x 45 x 35 mm, massa 0,30 kg; contato plano Ø30 x 3 | Hipótese |
| Fixadores | M4 para estruturas e guias, M3 quando compatível com carro dos atuadores; furos reais por STEP | Pré-seleção |

**Atenção a CAD:** para peças compradas, importar STEP do fabricante, manter a geometria oficial e criar *brackets* ao redor dela. Não supor que distâncias entre furos, interfaces de servo, interfaces de drone e tolerâncias foram definidas por este memorial. Fazer verificações de curso máximo, interferência e comprimento de engate das guias.

## 4. Razão da seleção de componentes

A **Matrice 400** foi selecionada pela folga de capacidade estática nominal (a integração de carga móvel continua sujeita a ensaio). A DJI especifica até **6 kg no terceiro suporte, com fixação por parafusos**, e oferece alimentação/integração via E-Port V2, com até **120 W por porta**, sujeitos ao SDK e à integração correta.

O **DYNAMIXEL XM430-W350-T** fornece encoder, controle de posição e volume compacto. Seu torque de bloqueio (**4,1 N·m**) não é torque de operação contínua; a ROBOTIS informa uma estimativa de apenas **0,82 N·m** para serviço contínuo. As cargas de peso/momento não devem ser suportadas diretamente pelos rolamentos internos do servo: usar mancais externos.

Os **Actuonix T16** possuem cursos de **100 e 200 mm**, posição realimentada, força máxima anunciada **90 N**, velocidade máxima sem carga **18 mm/s** e ciclo máximo **20%**. Os modelos “P” requerem controlador externo apropriado. Não são considerados adequados para ambiente offshore sem comprovação de estanqueidade e proteção adicionais.

A guia **igus N27** suporta momento nominal My/Mz de até **2,5 N·m** (caso e sentido conforme catálogo) e a **N40**, até **6 N·m**. São apenas pré-seleções, pois a verificação de carga combinada, vida e vibração requer layout e dados reais.

O **eletroímã Adafruit P25/20** indica retenção nominal de **5 kgf** sob contato ideal, mas o fornecedor recomenda reduzir a expectativa de levantamento em **5–10 vezes** e exige superfície plana ferromagnética. Para a carga inicialmente estabelecida (**300 g**), é indispensável ensaio com a ferramenta real e retenção redundante: a carga cairia se a alimentação do eletroímã fosse cortada.

## 5. Estimativas preliminares

### Inventário de massa

- Placa de montagem, mesa e chapas estruturais, com perfis: cálculo geométrico por densidade típica do alumínio, **2,70 g/cm³**.
- Massas de trilhos e carros: catálogos igus, usando pesos lineares e unidades dos modelos selecionados.
- Atuadores e eletroímã: fichas técnicas dos respectivos fornecedores.
- Outros (mancais, suportes, fios, fixadores, controladores): **estimativa provisória**, não pesagem real.

Resultado aproximado: **2,14 kg** de componentes/estrutura + **25% de reserva** = **2,68 kg** de manipulador; com ferramenta de **0,30 kg**, **2,98 kg de carga útil total prevista**. Isso é inferior aos 6 kg anunciados para o suporte específico da Matrice 400 e, combinada à massa básica de 9,74 kg, ficaria em torno de 12,72 kg ante MTOW 15,8 kg. Não há aprovação de voo implícita nesses números; a massa, posição do centro de gravidade e momento têm importância central.

### Momento simplificado

Com ferramenta de **0,30 kg** a **0,30 m** do eixo: M ≈ 0,30 × 9,81 × 0,30 = **0,883 N·m**. Incluindo o ímã de **0,0553 kg** no mesmo raio, chega a ~**1,046 N·m**. Se houver outros **0,25 kg** de massa móvel com raio médio de **0,16 m**, estimamos **~1,44 N·m** de momento estático, antes de considerarmos outras massas e acelerações. Uma multiplicação exploratória por 2 dá **~2,88 N·m**, mas não constitui fator de segurança certificado. O modelo real deverá calcular as distribuições de massa por peça, reações nas guias e momento transmitido à aeronave.

### Alimentação e tempo

- T16: corrente de bloqueio de aproximadamente **1 A por atuador a 12 V**.
- XM430: corrente de bloqueio de **2,3 A a 12 V**.
- Ímã: **5 V × 0,3 A = 1,5 W**.
- Pré-seleção de distribuição: conversor **12 V / 6 A** mais **5 V / 1 A**, com drivers, proteção de corrente, diodos e integração correta ao E-Port V2. Não ligar motores diretamente ao conector sem projeto elétrico.
- No limite sem carga, deslocamentos de 100 e 200 mm demoram pelo menos **5,6 s** e **11,1 s**, respectivamente, a 18 mm/s; com carga pode ser mais lento. Respeitar ciclo de trabalho 20%.

## 6. Pendências que impedem fabricar ou voar

1. **Operação em painel vertical**: o raio do TCP de até **300 mm** não assegura alcançar um painel diante de um drone com dimensões abertas de **980 x 760 mm** (sem hélices). A distância da parede ao eixo do robô e o volume das hélices devem ser estudados. Pode ser necessário um painel adaptado ou um projeto de maior alcance.
2. **Pouso**: confirmar folga do trem de pouso, interferência do conjunto de ~240 mm de extensão vertical e posicionamento de cada conexão com envelope real da aeronave.
3. **Dinâmica do drone**: calcular centro de massa móvel, torque de arfagem/rolagem, possíveis instabilidades durante extensão e recolhimento e ações de vento. A capacidade estática nominal de carga não valida essa operação.
4. **Segurança**: eletroímã ativo sem redundância não é seguro em falha de alimentação. Especificar retenção passiva adicional ou estudar ímã eletropermanente compatível.
5. **Posicionamento fino**: as tolerâncias de voo estacionário não substituem visão local e uma estação projetada para contato milimétrico; exigir sensor de contato e inspeção visual/câmera.
6. **Confiabilidade e ambiente**: ciclos de trabalho, resistência a vibração, impacto, água salgada, corrosão, proteção elétrica, travamento passivo e planos de manutenção.
7. **Detalhamento de fabricação**: faltam dados de montagem do drone, STEP de componentes, fixadores aprovados, tolerâncias, material de vedação, testes de força e análise estrutural/fadiga.
8. **Operação e regulamentação**: exigências da ANAC, DECEA/SARPAS e do local industrial/offshore para qualquer voo real.

## 7. Próximos passos para Claude + FreeCAD

1. Importar o arquivo `dimensoes_ARM_RPP_v01.yaml` e os PDFs originais.
2. Criar uma planilha `Parametros` no FreeCAD com aliases para dimensões assumidas e para coordenadas `theta1`, `d2`, `d3`.
3. Importar modelos STEP oficiais de XM430, T16 (100 e 200), guias igus e demais componentes sempre que disponíveis; nunca substituí-los por caixas com furos supostos quando a finalidade for fabricar.
4. Modelar em sequência base, eixo de rotação, carro vertical, carro horizontal e ímã, preservando referencial e cadeia RPP.
5. Verificar recolhimento/extensão, interferências, distribuição de massas e colisão com modelo real do drone, se houver STEP dele.
6. Exportar FreeCAD (`.FCStd`), STEP e relatório de pendências. Marcar explicitamente `NÃO VALIDADO PARA VOO`.

## 8. Fontes pesquisadas

- Relatório do grupo, *Projeto de Manipulador* (USP, ago/2026), página 2; slides *Cinemática Direta*, páginas 2 e 7; slides *Modelagem Dinâmica*, páginas 3 e 15.
- DJI Matrice 400, especificações: https://enterprise.dji.com/matrice-400/specs
- DJI Matrice 400, FAQ / payload: https://enterprise.dji.com/matrice-400/faq
- Actuonix T16 vertical: https://www.actuonix.com/t16-100-64-12-p
- Actuonix T16 horizontal: https://www.actuonix.com/t16-200-64-12-p
- Actuonix T16 datasheet: https://www.actuonix.com/assets/images/datasheets/ActuonixT16Datasheet.pdf
- igus N27 e N40: https://www.igus.com.br/tecnologia-linear/guias-de-baixo-perfil/instrucoes-de-montagem
- ROBOTIS XM430-W350-T: https://robotis.us/products/dynamixel-xm430-w350-t
- Adafruit P25/20: https://www.adafruit.com/product/3873
- SKF 6001: https://www.skf.com/
- MatWeb Alumínio 6061-T6: https://asm.matweb.com/search/SpecificMaterial.asp?bassnum=MA6061T6
- DECEA: https://www.decea.mil.br/drone/

**Conclusão:** os parâmetros agora são suficientes para um **CAD conceitual paramétrico específico**, não para declarar “todas as dimensões de fabricação resolvidas”.
